# Face-Recognizer-Using-LBPH-Recognizer

This is a Desktop Application on Face Recognition Using LBPH Recognizer.

Follow this video to understand the functionality of this code:
https://www.youtube.com/watch?v=VTcMFtaIhag&lc=UgxbVdKzSQlvsEw9QLN4AaABAg
